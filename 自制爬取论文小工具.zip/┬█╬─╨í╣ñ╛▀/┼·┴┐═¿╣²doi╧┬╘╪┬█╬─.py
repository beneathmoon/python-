import requests
from bs4 import BeautifulSoup

search_url = 'https://kns.cnki.net/kns/brief/result.aspx'
params = {'pagename': 'ASP.brief_default_result_aspx', 'dbPrefix': 'CJFQ', 'dbCatalog': '中国学术期刊网络出版总库', 'ConfigFile': 'CJFQ.xml', 'research': 'off', 'keyValue': '标题', 'S': '1', 'sorttype': '', 'showmode': 'list', 'x': '0', 'y': '0'}
response = session.get(search_url, params=params)
soup = BeautifulSoup(response.text, 'html.parser')

# 获取所有论文链接
paper_links = []
for a in soup.find_all('a', {'class': 'fz14'}):
    paper_links.append(a['href'])

# 下载所有论文PDF文件
for link in paper_links:
    pdf_url = link.replace('/Article/', '/kns/download.aspx?filename=')
    response = session.get(pdf_url)
    with open(f"{link.split('/')[-1]}.pdf", "wb") as f:
        f.write(response.content)
    print(f"File saved as {link.split('/')[-1]}.pdf")