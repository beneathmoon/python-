import requests
import re
import time
import random
import_f='信息熵和城市规划综述.txt'
export_f='信息熵和城市规划综述doi.txt'

# 获取标题
with open(import_f,'r',encoding='utf-8') as f:
    titles = f.read().splitlines()
headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'}

a=0
b=30

def get_doi(title):
    url = 'https://api.crossref.org/works?query=' + title
    response = requests.get(url,headers=headers)
    result = response.json()
    if 'message' in result and 'total-results' in result['message'] and result['message']['total-results'] > 0:
        doi = result['message']['items'][0]['DOI']
        return doi
    else:
        return None

with open(export_f, 'w', encoding='utf-8') as f:
    for i,title in enumerate(titles):
       if a<i<=b:
          doi = get_doi(title)
          if doi:
            print(doi)
          else:
            print(title + ': doi not found')
          time.sleep(random.randint(1, 5))


'''
with open('所有doi.txt', 'w', encoding='utf-8') as f:
    for i, title in enumerate(titles):
        doi = get_doi(title)
        if doi:
            print(f"{i+1}: {doi}")
            f.write(doi+'\n')
        else:
            print(f"{i+1}: {title} - DOI not found")

def get_doi(title):
    url = 'https://api.crossref.org/works?query=' + title
    response = requests.get(url)
    result = response.json()
    if result['message']['total-results'] > 0:
        doi = result['message']['items'][0]['DOI']
        return doi
    else:
        return None


