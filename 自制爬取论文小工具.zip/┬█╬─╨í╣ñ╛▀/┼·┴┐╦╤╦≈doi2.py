import requests
import re
import time
import random

# 获取标题
with open('论文引用文献1.txt', 'r', encoding='utf-8') as f:
    titles = f.read().splitlines()

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
}

# 分段获取
a = 98
b = 120


def get_doi(title):
    url = 'https://api.crossref.org/works?query=' + title
    response = requests.get(url, headers=headers)
    result = response.json()
    if 'message' in result and 'total-results' in result['message'] and result['message']['total-results'] > 0:
        doi = result['message']['items'][0]['DOI']
        return doi
    else:
        return None


with open('doi3.txt', 'w', encoding='utf-8') as f:
    for i, title in enumerate(titles):
        if a < i <= b:
            doi = get_doi(title)
            if doi:
                print(str(i)+':'+doi)
                f.write(str(i)+':'+doi + '\n')
                print
            else:
                print(title + ': doi not found')
            time.sleep(random.randint(1, 5))
