import  requests
import  re
import time
import random
with open("doi.txt", "r") as f:
    lines = f.readlines()

for i in range(len(lines)):
    lines[i] = re.sub(r'^\d+:', '', lines[i])

with open("doi.txt", "w") as f:
    for line in lines:
        f.write(line)

with open('doi.txt', 'r') as f:
    dois = f.read().splitlines()

aa=37
b=120
for i, doi in enumerate(dois):
    if aa < i <= b:
        url = f'http://dx.doi.org/{doi}'
        headers = {
            'Accept': 'application/x-bibtex',
            'Crossref-Plus-Citation-Style': 'no-doi-no-url'
        }
        response = requests.get(url, headers=headers)
        # 判断是否有doi
        if response:
            print(response)
        else:
            print(doi + 'not find')
        # 写入文件
        with open('output1.bib', 'a', encoding='utf-8') as f:  # 修改这里的写入模式
            f.write('\n\n\n' + response.text + '\n\n\n')
        time.sleep(random.randint(1, 5))


with open('output1.bib', 'r') as f:
    bib = f.read()

bib = re.sub(r'\bdoi\s*=\s*\{[^}]*\},?\s*', '', bib)
bib = re.sub(r'\burl\s*=\s*\{[^}]*\},?\s*', '', bib)

with open('output1.bib', 'w') as f:
    f.write(bib)
