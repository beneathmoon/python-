with open('doi2.txt', 'r') as file:
    data1 = file.read().splitlines()
with open('待删除doi.txt', 'r') as file:
    data2 = file.read().splitlines()

filtered_data = [d for d in data1 if d not in data2]  #列表推导式

with open('不重复.txt', 'w') as file:
    file.write('\n'.join(filtered_data))
